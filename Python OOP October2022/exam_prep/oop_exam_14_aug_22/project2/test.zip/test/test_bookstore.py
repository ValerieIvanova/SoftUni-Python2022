from project.bookstore import Bookstore
from unittest import TestCase, main


class TestBookstore(TestCase):
    def setUp(self) -> None:
        self.bookstore = Bookstore(10)

    def test_correct_initializing(self):
        self.assertEqual(self.bookstore.books_limit, 10)
        self.assertEqual(self.bookstore.availability_in_store_by_book_titles, {})
        self.assertEqual(self.bookstore.total_sold_books, 0)

    def test_books_limit_setter_with_wrong_data_raise_value_error(self):
        with self.assertRaises(ValueError) as ve:
            self.invalid_bookstore = Bookstore(0)
        self.assertEqual("Books limit of 0 is not valid", str(ve.exception))

        with self.assertRaises(ValueError) as error:
            self.bookstore.books_limit = -1

        self.assertEqual("Books limit of -1 is not valid", str(error.exception))

    def test_len_method(self):
        self.bookstore.availability_in_store_by_book_titles = {'test': 10, 'test2': 20}
        result = len(self.bookstore)
        self.assertEqual(30, result)

    def test_receive_books_when_space_is_not_enough_raise_exception(self):
        with self.assertRaises(Exception) as ex:
            self.bookstore.receive_book('Test2', 100)
        self.assertEqual("Books limit is reached. Cannot receive more books!", str(ex.exception))

    def test_receive_book_when_space_is_enough(self):
        self.bookstore.availability_in_store_by_book_titles = {'book1': 1}
        self.bookstore.receive_book('book1', 2)
        self.assertEqual(self.bookstore.availability_in_store_by_book_titles, {'book1': 3})
        self.bookstore.receive_book('book2', 3)
        self.assertEqual(self.bookstore.availability_in_store_by_book_titles, {'book1': 3, 'book2': 3})

    def test_get_total_count_of_the_received_book(self):
        self.bookstore.availability_in_store_by_book_titles = {'book1': 1}
        result = self.bookstore.receive_book('book1', 2)
        self.assertEqual("3 copies of book1 are available in the bookstore.", result)

    def test_trying_to_sell_unavailable_book_raise_exception(self):
        self.bookstore.availability_in_store_by_book_titles = {'book1': 2, 'book2': 3}
        with self.assertRaises(Exception) as ex:
            self.bookstore.sell_book('book3', 3)
        self.assertEqual("Book book3 doesn't exist!", str(ex.exception))

    def test_trying_to_sell_a_book_with_not_enough_copies_raise_exception(self):
        self.bookstore.availability_in_store_by_book_titles = {'book1': 2, 'book2': 3}
        with self.assertRaises(Exception) as ex:
            self.bookstore.sell_book('book1', 3)
        self.assertEqual("book1 has not enough copies to sell. Left: 2", str(ex.exception))

    def test_sell_successfully(self):
        self.bookstore.availability_in_store_by_book_titles = {'book1': 2, 'book2': 3}

        result = self.bookstore.sell_book('book1', 1)
        self.assertEqual(self.bookstore.availability_in_store_by_book_titles, {'book1': 1, 'book2': 3})
        self.assertEqual(self.bookstore.total_sold_books, 1)
        self.assertEqual("Sold 1 copies of book1", result)
        self.assertEqual(len(self.bookstore), 4)

        result2 = self.bookstore.sell_book('book1', 1)
        self.assertEqual(self.bookstore.availability_in_store_by_book_titles, {'book1': 0, 'book2': 3})
        self.assertEqual(self.bookstore.total_sold_books, 2)
        self.assertEqual("Sold 1 copies of book1", result2)
        self.assertEqual(len(self.bookstore), 3)

    def test_str_method_if_books(self):
        self.bookstore.availability_in_store_by_book_titles = {'book1': 2, 'book2': 3}
        self.bookstore.sell_book('book1', 1)
        result = str(self.bookstore)
        self.assertEqual("Total sold books: 1\n"
                         "Current availability: 4\n"
                         " - book1: 1 copies\n"
                         " - book2: 3 copies"
                         , result)

    def test_str_method_if_not_books(self):
        self.bookstore.availability_in_store_by_book_titles = {'book1': 2}
        self.bookstore.sell_book('book1', 2)
        result = str(self.bookstore)
        self.assertEqual("Total sold books: 2\n"
                         "Current availability: 0\n"
                         " - book1: 0 copies"
                         , result)


if __name__ == '__main__':
    main()
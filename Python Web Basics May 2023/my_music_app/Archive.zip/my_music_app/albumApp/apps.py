from django.apps import AppConfig


class AlbumappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'my_music_app.albumApp'
